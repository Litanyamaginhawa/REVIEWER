const CACHE='litanya-push-v1';

self.addEventListener('install', event => self.skipWaiting());
self.addEventListener('activate', event => event.waitUntil(self.clients.claim()));

self.addEventListener('push', event => {
  let data = {};
  try { data = event.data ? event.data.json() : {}; } catch (_) {}
  const title = data.title || 'LitanyaSpace';
  const options = {
    body: data.body || 'There is a new post on LitanyaSpace.',
    tag: data.tag || 'litanya-new-post',
    renotify: true,
    data: { url: data.url || '/' },
    requireInteraction: false
  };
  event.waitUntil(self.registration.showNotification(title, options));
});

self.addEventListener('notificationclick', event => {
  event.notification.close();
  const target = event.notification.data?.url || '/';
  event.waitUntil((async () => {
    const windows = await clients.matchAll({type:'window', includeUncontrolled:true});
    for (const client of windows) {
      try {
        const u = new URL(client.url);
        const t = new URL(target, self.location.origin);
        if (u.origin === t.origin) {
          if (typeof client.navigate === 'function') await client.navigate(t.href);
          await client.focus();
          return;
        }
      } catch (_) {}
    }
    if (clients.openWindow) await clients.openWindow(target);
  })());
});
